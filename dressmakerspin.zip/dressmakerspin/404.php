<?php get_header(); ?>

<div class="container">

	<div class="row">

			<section class="col-sm-12">

				<article class="subpages-article">

					<h1 class="subpages-title">Nie ma takiej strony :-(</h1>

					<p class="profile-description subpage"><strong>Niestety nie udało się znaleźć takiej strony.</strong><br>Być może jest to chwilowy błąd, jeśli chcesz możesz wejść na moją stronę główną <a href="<?php echo home_url(); ?>">klikając tutaj</a> :-)</p>

				</article>

			</section>

	</div>	<!-- /.row -->

</div>	<!-- /.container -->

<?php get_footer(); ?>
