#blank-bootstrap-wp-theme

I created this theme as a starting point for my theme development, feel free to use it for your new projects. 
Current Bootstrap version is 3.3.4

###Header file includes
* Bootstrap css and js plus responsive
* Jquery js from google api
* Menu


###Index file includes
* Main Wp loop
* Sidebar

###Function file include
* Post thumbnails
* Menu Support
* registered sidebar
* Gravity forms submit button bootstrap btn class

